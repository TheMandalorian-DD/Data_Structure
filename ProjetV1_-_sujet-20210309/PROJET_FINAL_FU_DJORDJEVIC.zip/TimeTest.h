#include "Chaine.h"
const int NB_Points_Chaine = 100;
const int X_MAX = 5000;
const int Y_MAX = 5000;

Chaines* generationAleatoire(int nbChaines, int nbPointsChaine, int xmax, int ymax);

